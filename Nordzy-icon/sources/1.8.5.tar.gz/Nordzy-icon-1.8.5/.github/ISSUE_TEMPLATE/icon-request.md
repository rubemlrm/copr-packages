---
name: Icon request
about: Request a missing icon's application
title: "[ICON]"
labels: enhancement, icon request
assignees: ''

---

Application name: 
Icon name if you know it: 
Original icon image: 
Use tray?
Small description and/or a link to the official webpage:
